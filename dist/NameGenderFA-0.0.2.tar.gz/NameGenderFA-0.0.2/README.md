# NameGenderFA
Detecting gender of Persian names with auto cleaning the input
